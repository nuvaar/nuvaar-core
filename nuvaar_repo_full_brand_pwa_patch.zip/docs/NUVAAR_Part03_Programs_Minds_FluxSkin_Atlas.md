# NUVAAR Omega Full Launch
# Part 03 - Programs: Minds, FluxSkin, Atlas

Language is English only. ASCII only.

## 1. Minds of the Rejected
- Cells of 3 to 12 people
- Roles: Maker, Facilitator, Observer or Mentor
- Cycle 6 to 12 weeks with gates and micro grants
- Public outcomes and care reviews
- Tools: shared board, check ins, milestones, and end reports

## 2. FluxSkin
- Ethical device concept with repair and care
- Safety and accessibility basics
- Materials and disposal guidance
- Community workshops and kits
- Licensing and right to repair stance

## 3. Atlas
- Editorial policy and submission guide
- Translation and preservation plan
- Open licenses with credits
- Discoverability tags and stable URLs
- Corrections and takedown policy

## 4. Quality Rubrics
Simple rubrics for outcome clarity, safety, accessibility, and contribution to culture.

## 5. Onboarding To Programs
Join form, consent and privacy summary, matching, kickoff, and a demo day.
