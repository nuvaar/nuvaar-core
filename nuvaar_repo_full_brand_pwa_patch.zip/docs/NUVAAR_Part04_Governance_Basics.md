# NUVAAR Omega Full Launch
# Part 04 - Governance Basics

Language is English only. ASCII only.

## 1. Roles
Founder Steward, Members, Facilitators, Treasurer, Data Steward, Ethics Council, Advisors.

## 2. Decision Classes
Routine, Program, Treasury, and Constitutional. Each has a path and a review step.

## 3. Voting
Snapshot for open recording. Delegates for those who do not use wallets. Quorum targets and clear windows.

## 4. Treasury
Safe with multiple signers and thresholds. Spending policies by amount. Receipts and references linked to proposals.

## 5. Transparency
Public proposals, votes, budgets, and reports with redactions for privacy.

## 6. Conflict Resolution
Ladder with dialogue, facilitation, council review, and vote if needed.

## 7. Amendments
Supermajority with a cooling off period and ethics non objection.
