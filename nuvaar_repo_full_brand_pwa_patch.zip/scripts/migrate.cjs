
import { execSync } from "node:child_process";
const db = process.env.SUPABASE_DB_URL || "";
if (!db) { console.error("Missing SUPABASE_DB_URL"); process.exit(1); }
execSync(`psql ${db} -f infra/supabase/schema.sql`, { stdio: "inherit" });
execSync(`psql ${db} -f infra/supabase/policies.sql`, { stdio: "inherit" });
console.log("Migration complete");
