## Summary
Explain the change and why it is needed.

## Screenshots
If UI changes, add before and after.

## Checklist
- [ ] Tests pass
- [ ] Env variables documented
- [ ] Security and privacy reviewed
