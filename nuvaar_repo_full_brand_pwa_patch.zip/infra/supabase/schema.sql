
create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  role text not null check (role in ('member','facilitator','mentor','treasurer','council')),
  created_at timestamptz default now()
);
create table if not exists public.profiles (
  user_id uuid primary key references public.users(id) on delete cascade,
  display_name text,
  bio text,
  skills text[],
  country text,
  lang text,
  privacy_opt boolean default true
);
create table if not exists public.cells (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  facilitator_id uuid references public.users(id),
  status text not null default 'active',
  created_at timestamptz default now()
);
create table if not exists public.cell_members (
  cell_id uuid references public.cells(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  role text not null default 'member',
  joined_at timestamptz default now(),
  primary key (cell_id, user_id)
);
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  cell_id uuid references public.cells(id) on delete cascade,
  title text not null,
  outcome text,
  milestone_json jsonb default '[]'::jsonb,
  status text not null default 'in_progress',
  public_url text,
  created_at timestamptz default now()
);
create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references public.projects(id) on delete cascade,
  amount_usd numeric(12,2) not null,
  kind text not null check (kind in ('grant','fee','expense','donation','payout')),
  tx_ref text,
  created_at timestamptz default now()
);
create table if not exists public.incidents (
  id uuid primary key default gen_random_uuid(),
  cell_id uuid references public.cells(id) on delete set null,
  severity text not null check (severity in ('sev1','sev2','sev3')),
  note text,
  created_at timestamptz default now(),
  resolved_at timestamptz
);
create table if not exists public.kpis (
  id uuid primary key default gen_random_uuid(),
  metric text not null,
  value numeric not null,
  window text not null,
  note text,
  created_at timestamptz default now()
);
