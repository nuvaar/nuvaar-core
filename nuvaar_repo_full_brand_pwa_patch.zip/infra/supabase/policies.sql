
alter table public.users enable row level security;
alter table public.profiles enable row level security;
alter table public.cells enable row level security;
alter table public.cell_members enable row level security;
alter table public.projects enable row level security;
alter table public.transactions enable row level security;
alter table public.incidents enable row level security;
alter table public.kpis enable row level security;

create policy profiles_self on public.profiles
  for select using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy cells_public on public.cells for select using (true);
create policy cell_members_by_user on public.cell_members for select using (auth.uid() = user_id);

create policy projects_by_cell on public.projects
  for select using (
    exists (
      select 1 from public.cell_members m
      where m.cell_id = projects.cell_id and m.user_id = auth.uid()
    )
  );

create policy kpis_public on public.kpis for select using (true);
