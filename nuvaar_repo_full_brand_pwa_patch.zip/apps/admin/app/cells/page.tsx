export default function Page() {
  return <section className="space-y-4"><h1 className="text-2xl font-semibold">Cells</h1><p>Table will appear here.</p></section>;
}
