export function GET() {
  return new Response("User-agent: *\nAllow: /\nSitemap: https://nuvaar.xyz/sitemap.xml", { headers: { "content-type": "text/plain" } });
}
