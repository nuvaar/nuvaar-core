
export default function Page() {
  return <pre>ok {new Date().toISOString()}</pre>;
}
