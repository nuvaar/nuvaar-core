
export default function Page() {
  return (
    <section className="space-y-8">
      <h1 className="text-3xl font-semibold">Dignity. Small groups. Real outcomes.</h1>
      <p>NUVAAR helps people turn creativity into livelihood with care. Cells, ethical design, and a cultural archive.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-md p-4 border border-[color:var(--muted)]">
          <div className="text-sm text-[color:var(--muted)]">Active Cells</div>
          <div className="text-2xl font-semibold">5</div>
        </div>
        <div className="rounded-md p-4 border border-[color:var(--muted)]">
          <div className="text-sm text-[color:var(--muted)]">Completed Projects</div>
          <div className="text-2xl font-semibold">20</div>
        </div>
        <div className="rounded-md p-4 border border-[color:var(--muted)]">
          <div className="text-sm text-[color:var(--muted)]">Atlas Works</div>
          <div className="text-2xl font-semibold">10</div>
        </div>
      </div>
    </section>
  );
}
