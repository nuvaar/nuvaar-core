
import * as React from "react";
export function KpiTile({ label, value, trend }: { label: string; value: string | number; trend?: string }) {
  return (
    <div className="rounded-md p-4 border border-[color:var(--muted)]">
      <div className="text-sm text-[color:var(--muted)]">{label}</div>
      <div className="text-2xl font-semibold text-[color:var(--text)] mt-1">{value}</div>
      {trend && <div className="text-xs mt-1">{trend}</div>}
    </div>
  );
}
