
module.exports = { root: false, extends: ["next/core-web-vitals"], rules: { "@next/next/no-img-element": "off" } };
