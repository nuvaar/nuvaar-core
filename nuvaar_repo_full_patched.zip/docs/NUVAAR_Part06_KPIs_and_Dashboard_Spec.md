# NUVAAR Omega Full Launch
# Part 06 - KPIs and Dashboard Specification

Language is English only. ASCII only.

## 1. KPI Families
Activity, Production, Livelihood, Safety, and Culture.

## 2. Definitions
- Weekly active users: unique accounts with actions in 7 days
- Active cells: cells with check in or deliverable in 14 days
- Retention 30 day: cohort overlap percent
- Completed projects: status done within period
- Lead time: median days from start to outcome
- Ecosystem income: total USD equivalent in period
- Payout median: days from approval to payment
- Incidents by severity and mean time to resolve
- Atlas works and translations count

## 3. Data Model
Table kpi_daily with metric, value, window, collected_at, and note. No personal data in dashboards.

## 4. Refresh And SLA
Daily refresh by 02:00 UTC. Dashboard ready by 08:00 local time. Public tiles on Home.

## 5. Visualization
Lines for activity, bars for production, stacked areas for income, table for safety, and list for culture.

## 6. Review Cadence
Weekly check, monthly report, and quarterly reset.
