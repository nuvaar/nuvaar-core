# Contributing to NUVAAR

1. Fork and create a feature branch.
2. Follow conventional commits if possible.
3. Write tests when adding features.
4. Open a pull request and link any issues.
