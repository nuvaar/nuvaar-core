import "../styles/globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta name="title" content="NUVAAR - Dignity. Small groups. Real outcomes." />
        <meta name="description" content="NUVAAR helps people build creative livelihood with dignity." />
        <meta property="og:title" content="NUVAAR" />
        <meta property="og:description" content="Dignity. Small groups. Real outcomes." />
        <meta property="og:image" content="/og.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body className="bg-[color:var(--bg)] text-[color:var(--text)]">
        <header className="max-w-5xl mx-auto p-4 flex items-center justify-between">
          <a href="/" className="font-semibold">NUVAAR</a>
          <nav className="space-x-4">
            <a href="/vision">Vision</a>
            <a href="/minds">Minds</a>
            <a href="/fluxskin">FluxSkin</a>
            <a href="/atlas">Atlas</a>
            <a href="/join" className="px-3 py-1 rounded-md bg-[color:var(--accent)] text-black">Join</a>
          </nav>
        </header>
        <main className="max-w-5xl mx-auto p-4">{children}</main>
        <footer className="max-w-5xl mx-auto p-4 border-t border-[color:var(--muted)] mt-16 text-sm">
          <div className="flex flex-wrap items-center gap-4">
            <a href="/docs/terms">Terms</a>
            <a href="/docs/privacy">Privacy</a>
            <a href="/docs/cookies">Cookies</a>
            <span>legal@nuvaar.xyz</span>
          </div>
        </footer>
      </body>
    </html>
  );
}
