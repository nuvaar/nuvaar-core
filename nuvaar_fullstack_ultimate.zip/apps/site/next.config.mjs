
import { createRequire } from "module";
const require = createRequire(import.meta.url);
let withSentry = (c)=>c;
try { withSentry = require("@sentry/nextjs").withSentryConfig; } catch {}
const base = { reactStrictMode: true, experimental: { optimizePackageImports: ["@supabase/supabase-js"] } };
export default withSentry(base, { silent: true });
