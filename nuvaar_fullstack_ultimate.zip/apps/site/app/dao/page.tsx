
const SNAPSHOT_SPACE = process.env.SNAPSHOT_SPACE_ID;
const SAFE_ADDR = process.env.SAFE_TREASURY_ADDRESS;
const SAFE_CHAIN_PREFIX = process.env.SAFE_CHAIN_PREFIX || "eth";
export default function DAOPage(){
  const snapshotUrl = SNAPSHOT_SPACE ? `https://snapshot.org/#/${SNAPSHOT_SPACE}` : undefined;
  const safeUrl = SAFE_ADDR ? `https://app.safe.global/home?safe=${SAFE_CHAIN_PREFIX}:${SAFE_ADDR}` : undefined;
  return (<main className="p-8 space-y-6"><h1 className="text-2xl font-semibold">DAO Transparency</h1>
    <section className="space-y-2"><h2 className="text-xl">Snapshot</h2>{snapshotUrl ? <a className="underline" href={snapshotUrl} target="_blank">Open Snapshot Space</a> : <p>Set SNAPSHOT_SPACE_ID in env.</p>}</section>
    <section className="space-y-2"><h2 className="text-xl">Treasury (Safe)</h2>{safeUrl ? <a className="underline" href={safeUrl} target="_blank">Open Safe Dashboard</a> : <p>Set SAFE_TREASURY_ADDRESS and SAFE_CHAIN_PREFIX.</p>}</section>
  </main>);
}
