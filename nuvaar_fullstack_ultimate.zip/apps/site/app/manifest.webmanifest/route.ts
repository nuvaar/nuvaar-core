
export function GET() {
  const data = {
    name: "NUVAAR",
    short_name: "NUVAAR",
    start_url: "/",
    display: "standalone",
    background_color: "#0b0d0f",
    theme_color: "#0fe1c7",
    icons: [
      { src: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }
    ]
  };
  return new Response(JSON.stringify(data), { headers: { "content-type": "application/manifest+json" } });
}
