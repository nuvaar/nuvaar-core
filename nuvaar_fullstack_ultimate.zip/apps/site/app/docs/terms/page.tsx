
export default function Page(){
  const md = `Replace with official text`;
  return <article><pre style={{whiteSpace:"pre-wrap"}}>{md}</pre></article>;
}
