
export default function NotFound(){
  return <main className="p-8"><h1 className="text-2xl font-semibold">Not Found</h1></main>;
}
