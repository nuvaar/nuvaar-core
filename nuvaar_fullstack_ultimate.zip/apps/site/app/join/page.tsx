
"use client";
import { useState } from "react"; import { submitJoin } from "@/lib/joinClient";
export default function JoinPage(){
  const [ok,setOk] = useState<boolean|null>(null);
  const [loading,setLoading] = useState(false);
  async function onSubmit(e: React.FormEvent<HTMLFormElement>){
    e.preventDefault(); setLoading(true);
    const res = await submitJoin(e.currentTarget);
    setLoading(false); setOk(!!res?.ok);
    if(res?.ok) e.currentTarget.reset();
  }
  return (<section className="max-w-2xl">
    <h1 className="text-3xl font-semibold mb-4">Join NUVAAR</h1>
    <form onSubmit={onSubmit} className="grid gap-4">
      <label className="grid gap-1"><span>Name</span><input name="name" required className="p-2 rounded bg-surface" /></label>
      <label className="grid gap-1"><span>Email</span><input type="email" name="email" required className="p-2 rounded bg-surface" /></label>
      <label className="grid gap-1"><span>Country</span><input name="country" className="p-2 rounded bg-surface" /></label>
      <label className="grid gap-1"><span>How do you want to contribute?</span><textarea name="about" rows={5} className="p-2 rounded bg-surface" /></label>
      <button disabled={loading} className="px-4 py-2 rounded bg-accent text-black w-max">{loading ? "Sending..." : "Send"}</button>
    </form>
    {ok===true && <p className="mt-4 text-green-400">Thanks. We will get back to you.</p>}
    {ok===false && <p className="mt-4 text-red-400">Something went wrong. Please try again later.</p>}
  </section>);
}
