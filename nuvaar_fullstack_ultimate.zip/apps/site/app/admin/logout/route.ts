
import { clearAdminCookie } from "@/lib/authrbac";
export async function POST(){ return clearAdminCookie(new Response(null,{ status:302, headers:{ Location:"/" } })); }
