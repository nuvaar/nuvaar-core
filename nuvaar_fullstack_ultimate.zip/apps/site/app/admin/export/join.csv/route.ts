
import { supabaseAdmin } from "@/lib/supabaseAdmin";
export async function GET(){ const { data, error } = await supabaseAdmin.from("join_requests").select("*").order("created_at",{ascending:false});
  if(error) return new Response("db_error",{status:500});
  const header=["id","created_at","name","email","country","about","ip","ua"].join(",");
  const rows=(data||[]).map((r:any)=>[r.id,r.created_at,r.name,r.email,r.country||"",JSON.stringify(r.about||"").replace(/,/g,";"),r.ip||"",JSON.stringify(r.ua||"").replace(/,/g,";")].join(","));
  const body=[header,...rows].join("\n");
  return new Response(body,{headers:{"content-type":"text/csv; charset=utf-8","cache-control":"no-store"}});
}
