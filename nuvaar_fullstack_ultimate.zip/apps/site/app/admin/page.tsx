
import Link from "next/link"; import { isAdminByCookie } from "@/lib/authrbac";
export default async function AdminHome(){
  if(!isAdminByCookie()) return <div className="p-8">Unauthorized</div>;
  return (<main className="p-8 space-y-6">
    <h1 className="text-2xl font-semibold">NUVAAR Admin</h1>
    <ul className="list-disc pl-6 space-y-2">
      <li><Link href="/admin/join-requests">Join requests</Link></li>
      <li><Link href="/admin/kpi">KPI dashboard</Link></li>
      <li><Link href="/admin/uploads">Asset uploads</Link></li>
    </ul>
    <form method="post" action="/admin/logout"><button className="mt-6 border px-3 py-1 rounded">Sign out</button></form>
  </main>);
}
