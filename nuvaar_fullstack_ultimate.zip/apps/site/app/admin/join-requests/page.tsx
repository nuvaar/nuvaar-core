
import { isAdminByCookie } from "@/lib/authrbac"; import { supabaseAdmin } from "@/lib/supabaseAdmin";
export default async function JR(){
  if(!isAdminByCookie()) return <div className="p-8">Unauthorized</div>;
  const { data } = await supabaseAdmin.from("join_requests").select("*").order("created_at",{ascending:false});
  return (<main className="p-8"><h1 className="text-2xl mb-4">Join requests</h1>
    <a className="underline" href="/admin/export/join.csv" target="_blank">Export CSV</a>
    <table className="w-full mt-6 border-collapse">
      <thead><tr><th className="border p-2">Date</th><th className="border p-2">Name</th><th className="border p-2">Email</th><th className="border p-2">Country</th><th className="border p-2">About</th></tr></thead>
      <tbody>{(data||[]).map((r:any)=>(<tr key={r.id}><td className="border p-2">{new Date(r.created_at).toLocaleString()}</td><td className="border p-2">{r.name}</td><td className="border p-2">{r.email}</td><td className="border p-2">{r.country||""}</td><td className="border p-2">{r.about||""}</td></tr>))}</tbody>
    </table></main>);
}
