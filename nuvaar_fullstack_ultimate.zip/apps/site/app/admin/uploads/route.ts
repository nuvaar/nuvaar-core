
import { isAdminByCookie } from "@/lib/authrbac";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
export const runtime = "nodejs";
function r2(){
  if(!process.env.R2_ENDPOINT||!process.env.R2_BUCKET||!process.env.R2_ACCESS_KEY_ID||!process.env.R2_SECRET_ACCESS_KEY) throw new Error("Missing R2 config");
  return new S3Client({ region:"auto", endpoint:process.env.R2_ENDPOINT, credentials:{ accessKeyId:process.env.R2_ACCESS_KEY_ID!, secretAccessKey:process.env.R2_SECRET_ACCESS_KEY! } });
}
export async function POST(req: Request){
  if(!isAdminByCookie()) return new Response("unauthorized",{status:401});
  const fd = await req.formData();
  const file = fd.get("file") as File | null;
  const path = String(fd.get("path") || "");
  if(!file || !path) return new Response("bad_request",{status:400});
  const buf = Buffer.from(await file.arrayBuffer());
  const client = r2();
  await client.send(new PutObjectCommand({ Bucket:process.env.R2_BUCKET!, Key:path, Body:buf, ContentType:file.type || "application/octet-stream" }));
  return new Response(JSON.stringify({ ok:true, key:path }), { headers: { "content-type":"application/json" } });
}
