
import { isAdminByCookie } from "@/lib/authrbac";
export default async function Uploads(){
  if(!isAdminByCookie()) return <div className="p-8">Unauthorized</div>;
  return (<main className="p-8 space-y-6"><h1 className="text-2xl">Asset uploads</h1>
    <form action="/admin/uploads" method="post" encType="multipart/form-data" className="space-y-4">
      <input name="file" type="file" className="block" required />
      <input name="path" type="text" placeholder="path/in/bucket.ext" className="border p-2 rounded w-full max-w-md" />
      <button className="border rounded px-4 py-2" type="submit">Upload</button>
    </form></main>);
}
