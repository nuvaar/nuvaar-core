
import { setAdminCookie } from "@/lib/authrbac";
export async function POST(req: Request){
  const fd = await req.formData();
  const token = String(fd.get("token") || "");
  const real = process.env.ADMIN_TOKEN || "";
  if(real && token === real){
    return setAdminCookie(new Response(null,{ status:302, headers:{ Location:"/admin" } }));
  }
  return new Response("unauthorized",{ status:401 });
}
