
export default function AdminLogin(){
  return (<form method="post" action="/admin/login" className="grid gap-4 p-8 max-w-sm">
    <h1 className="text-2xl font-semibold">Admin sign in</h1>
    <input name="token" type="password" placeholder="Admin token" className="p-2 rounded bg-surface"/>
    <button className="px-4 py-2 rounded bg-accent text-black">Enter</button>
  </form>);
}
