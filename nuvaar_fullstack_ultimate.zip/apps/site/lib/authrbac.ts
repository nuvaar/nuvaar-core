
import { cookies } from "next/headers";
export function isAdminByCookie(){
  const token = cookies().get("nuvaar_admin")?.value;
  const real = process.env.ADMIN_TOKEN;
  return !!real && token === real;
}
export function setAdminCookie(res: Response){
  res.headers.set("Set-Cookie", `nuvaar_admin=${process.env.ADMIN_TOKEN}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`);
  return res;
}
export function clearAdminCookie(res: Response){
  res.headers.set("Set-Cookie", "nuvaar_admin=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0");
  return res;
}
