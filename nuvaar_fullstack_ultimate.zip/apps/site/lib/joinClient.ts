
export async function submitJoin(form: HTMLFormElement){
  const fd = new FormData(form);
  const payload = {
    name: fd.get("name"),
    email: fd.get("email"),
    country: fd.get("country"),
    about: fd.get("about"),
    ua: typeof window !== "undefined" ? navigator.userAgent : ""
  };
  const res = await fetch("/api/join", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}
