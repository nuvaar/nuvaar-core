
export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];
export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; email: string | null; role: "admin"|"mentor"|"member"|null; display_name: string | null; created_at: string | null };
        Insert: { id: string; email?: string | null; role?: "admin"|"mentor"|"member"|null; display_name?: string | null; created_at?: string | null };
        Update: { email?: string | null; role?: "admin"|"mentor"|"member"|null; display_name?: string | null; created_at?: string | null };
      };
      join_requests: {
        Row: { id: string; created_at: string; name: string; email: string; country: string | null; about: string | null; ip: string | null; ua: string | null };
        Insert: { name: string; email: string; country?: string | null; about?: string | null; ip?: string | null; ua?: string | null };
        Update: { name?: string; email?: string; country?: string | null; about?: string | null; ip?: string | null; ua?: string | null };
      };
      kpis: {
        Row: { id: string; created_at: string; metric: string; value: number; window: string | null; note: string | null };
        Insert: { metric: string; value: number; window?: string | null; note?: string | null };
        Update: { metric?: string; value?: number; window?: string | null; note?: string | null };
      };
    };
  };
}
