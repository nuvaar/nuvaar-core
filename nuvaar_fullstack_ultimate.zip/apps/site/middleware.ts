
import type { NextRequest } from "next/server"; import { NextResponse } from "next/server";
export const config = { matcher: ["/api/:path*"] };
let m: Map<string, { c:number; t:number }> | null = null; const W=60000, L=10;
export async function middleware(req: NextRequest){
  const ip = req.ip || req.headers.get("x-forwarded-for") || "unknown";
  const key = ip+":"+new URL(req.url).pathname; const now=Date.now();
  if(!m) m = new Map(); const e = m.get(key);
  if(!e || now-e.t>W) m.set(key,{c:1,t:now}); else { e.c++; if(e.c> L) return new NextResponse("Too Many Requests",{status:429}); }
  return NextResponse.next();
}
