
import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0d0f",
        surface: "#14171a",
        text: "#e7e9ea",
        muted: "#9aa0a6",
        accent: "#0fe1c7"
      }
    }
  },
  darkMode: "class",
  plugins: []
};
export default config;
