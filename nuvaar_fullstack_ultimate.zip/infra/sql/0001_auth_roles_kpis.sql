
create table if not exists public.profiles (
  id uuid primary key,
  email text,
  role text check (role in ('admin','mentor','member')) default 'member',
  display_name text,
  created_at timestamptz default now()
);
create table if not exists public.kpis (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  metric text not null,
  value numeric not null,
  window text,
  note text
);
create table if not exists public.join_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  country text,
  about text,
  ip text,
  ua text
);
