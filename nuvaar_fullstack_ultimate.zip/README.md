
# NUVAAR

Production ready Next.js 14 App Router site with:
- Public marketing pages
- Join form with Supabase insert
- Admin panel protected by cookie token
- Join list with CSV export
- KPI dashboard with Recharts
- Asset uploads to Cloudflare R2 (S3 compatible)
- DAO page with Snapshot and Safe links
- SEO, sitemap, robots
- PWA manifest
- Rate limiting middleware

## Setup

1. Create a Supabase project and run the SQL in infra/sql/0001_auth_roles_kpis.sql.
2. Set environment variables from .env.example.
3. Deploy on Vercel or Netlify with root directory apps/site.

## Admin

Set ADMIN_TOKEN to a long random secret. Go to /admin/login to enter.
