
import * as React from "react";
export function Card({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section className="rounded-lg bg-[color:var(--surface)] shadow-md p-6">
      <header className="flex items-center justify-between">
        <h2 className="text-lg text-[color:var(--text)]">{title}</h2>
        {action}
      </header>
      <div className="mt-4 text-[color:var(--text)]">{children}</div>
    </section>
  );
}
