
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="p-6">
        <header className="mb-6"><a href="/" className="font-semibold">NUVAAR Admin</a></header>
        <main>{children}</main>
      </body>
    </html>
  );
}
