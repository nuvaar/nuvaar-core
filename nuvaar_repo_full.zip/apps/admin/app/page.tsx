
export default function Page() {
  return (
    <section className="space-y-4">
      <h1 className="text-2xl font-semibold">Admin</h1>
      <ul className="list-disc pl-6">
        <li><a href="/cells">Cells</a></li>
        <li><a href="/projects">Projects</a></li>
        <li><a href="/incidents">Incidents</a></li>
        <li><a href="/kpis">KPIs</a></li>
      </ul>
    </section>
  );
}
