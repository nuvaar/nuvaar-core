
insert into public.users (email, role) values
  ('founder@nuvaar.xyz', 'council')
  on conflict do nothing;
insert into public.users (email, role) values
  ('facilitator@nuvaar.xyz', 'facilitator')
  on conflict do nothing;
insert into public.users (email, role) values
  ('member1@nuvaar.xyz', 'member')
  on conflict do nothing;
insert into public.cells (name, facilitator_id)
select 'Cell Alpha', id from public.users where email='facilitator@nuvaar.xyz'
on conflict do nothing;
insert into public.cell_members (cell_id, user_id, role)
select c.id, u.id, 'facilitator'
from public.cells c
join public.users u on u.email='facilitator@nuvaar.xyz'
on conflict do nothing;
insert into public.cell_members (cell_id, user_id, role)
select c.id, u.id, 'member'
from public.cells c
join public.users u on u.email='member1@nuvaar.xyz'
on conflict do nothing;
insert into public.projects (cell_id, title, status)
select c.id, 'First Outcome', 'in_progress' from public.cells c limit 1;
