
create table if not exists public.join_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  country text,
  about text,
  ip text,
  ua text
);

alter table public.join_requests enable row level security;

create policy read_admin on public.join_requests
  for select to authenticated
  using (auth.role() = 'authenticated'); -- tighten by group/claim later

revoke all on table public.join_requests from anon;
