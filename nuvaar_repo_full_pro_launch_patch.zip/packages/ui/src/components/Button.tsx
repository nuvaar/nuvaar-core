
import * as React from "react";
type ButtonProps = {
  variant?: "primary" | "secondary" | "ghost" | "destructive";
  size?: "sm" | "md" | "lg";
  children: React.ReactNode;
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({ variant = "primary", size = "md", ...props }: ButtonProps) {
  const base = "inline-flex items-center justify-center rounded-md focus:outline-none focus-visible:ring transition";
  const sizes = { sm: "h-8 px-3 text-sm", md: "h-10 px-4 text-sm", lg: "h-12 px-6 text-base" }[size];
  const variants = {
    primary: "bg-[color:var(--accent)] text-black hover:opacity-90",
    secondary: "bg-[color:var(--surface)] text-[color:var(--text)] border border-[color:var(--muted)] hover:border-[color:var(--text)]",
    ghost: "bg-transparent text-[color:var(--text)] hover:bg-[color:var(--surface)]",
    destructive: "bg-red-600 text-white hover:bg-red-700"
  }[variant];
  return <button className={`${base} ${sizes} ${variants}`} {...props} />;
}
