# Security Policy

Please report vulnerabilities to security@nuvaar.xyz. We will acknowledge within 72 hours and publish a timeline after a fix.
