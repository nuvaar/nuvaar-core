
"use client";
export default function Error({ error }: { error: Error }) {
  return <main className="p-8"><h1 className="text-2xl font-semibold">Something went wrong</h1><pre>{error.message}</pre></main>;
}
