
export default function Home() {
  return (
    <section className="grid gap-10">
      <div className="grid gap-6">
        <img src="/brand/nuvaar-logo-dark.png" alt="NUVAAR" className="h-20 w-auto" />
        <h1 className="text-4xl font-semibold leading-tight">Dignity. Small groups. Real outcomes.</h1>
        <p className="text-lg text-[color:var(--muted)] max-w-2xl">
          NUVAAR organizes creative work and mutual support in small Cells so people can build livelihood with dignity.
        </p>
        <div className="flex gap-4">
          <a className="px-4 py-2 rounded bg-[color:var(--accent)] text-black" href="/join">Join</a>
          <a className="px-4 py-2 rounded border border-[color:var(--muted)]" href="/vision">Read the vision</a>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { title: "Cell-DAO", desc: "3-12 people, 6-12 weeks, clear outcomes and shared care." },
          { title: "Transparency", desc: "Snapshot votes and a multi-sig treasury you can verify." },
          { title: "Low-data", desc: "We collect the minimum required. People first, always." },
        ].map((c) => (
          <div key={c.title} className="p-4 rounded-lg bg-[color:var(--surface)] border border-[color:var(--muted)]">
            <h3 className="font-semibold mb-1">{c.title}</h3>
            <p className="text-[color:var(--muted)]">{c.desc}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-2">
        <h2 className="text-2xl font-semibold">Get involved</h2>
        <ul className="list-disc pl-6 text-[color:var(--muted)]">
          <li>Join a Cell and build something real</li>
          <li>Mentor or facilitate a group</li>
          <li>Support with grants and donations</li>
        </ul>
      </div>
    </section>
  );
}
