
export default function FluxSkin() {
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>FluxSkin</h1>
      <p>Bio-design for dignity. Practical, repairable, safe. Built with accessible materials, designed to last, and documented openly.</p>
      <h2>Highlights</h2>
      <ul>
        <li>Battery-free with inductive dock</li>
        <li>Safety and accessibility first</li>
        <li>Right-to-repair and care manuals</li>
      </ul>
    </article>
  );
}
