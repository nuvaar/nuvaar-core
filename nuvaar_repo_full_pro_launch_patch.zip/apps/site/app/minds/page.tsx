
export default function Minds() {
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Minds of the Rejected</h1>
      <p>Cells of 3-12 people work in 6-12 week cycles. Each cycle defines outcomes, gets micro-grants, publishes outputs, and learns.</p>
      <h2>Workflow</h2>
      <ol>
        <li>Apply and match to a Cell</li>
        <li>Define outcomes and milestones</li>
        <li>Fund with transparent micro-grants</li>
        <li>Publish results and reflect</li>
      </ol>
    </article>
  );
}
