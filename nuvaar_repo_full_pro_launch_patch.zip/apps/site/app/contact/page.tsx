export default function Page() {
  return <section className="space-y-4"><h1 className="text-2xl font-semibold">Contact</h1><p>Content coming soon.</p></section>;
}
