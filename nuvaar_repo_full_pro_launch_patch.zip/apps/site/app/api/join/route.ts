
import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export const runtime = "nodejs";

const Schema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  country: z.string().max(80).optional(),
  about: z.string().max(5000).optional(),
  ip: z.string().optional(),
  ua: z.string().optional()
});

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const parsed = Schema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: parsed.error.flatten() }, { status: 400 });
    }
    const { name, email, country, about, ip, ua } = parsed.data;

    const { error } = await supabaseAdmin
      .from("join_requests")
      .insert({ name, email, country, about, ip, ua });

    if (error) {
      console.error(error);
      return NextResponse.json({ ok: false, error: "db_error" }, { status: 500 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
  }
}
