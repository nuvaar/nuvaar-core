const urls = ["/","/vision","/minds","/fluxskin","/atlas","/join","/dao","/docs","/contact","/status"];
export function GET() {
  const xml = `<?xml version="1.0" encoding="UTF-8"?>` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">` +
    urls.map(u=>`<url><loc>https://nuvaar.xyz${u}</loc></url>`).join("") +
    `</urlset>`;
  return new Response(xml, { headers: { "content-type": "application/xml" } });
}
