
export default function Atlas() {
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Atlas</h1>
      <p>A living cultural engine: residencies, translation, and a public archive of works from our Cells.</p>
      <h2>Open Calls</h2>
      <p>We will publish open calls for artists and writers. Join the newsletter to get updates.</p>
    </article>
  );
}
