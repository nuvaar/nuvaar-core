
"use client";
import { useState } from "react";
import { submitJoin } from "@/lib/joinClient";

export default function JoinPage() {
  const [ok, setOk] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const result = await submitJoin(e.currentTarget);
    setOk(!!result?.ok);
    setLoading(false);
    if (result?.ok) e.currentTarget.reset();
  }

  return (
    <section className="max-w-2xl">
      <h1 className="text-3xl font-semibold mb-4">Join NUVAAR</h1>
      <p className="mb-6">Tell us about you. We store only what is needed to reach back and match you with a Cell.</p>
      <form onSubmit={onSubmit} className="grid gap-4">
        <label className="grid gap-1">
          <span>Name</span>
          <input name="name" required className="p-2 rounded bg-[color:var(--surface)]" />
        </label>
        <label className="grid gap-1">
          <span>Email</span>
          <input type="email" name="email" required className="p-2 rounded bg-[color:var(--surface)]" />
        </label>
        <label className="grid gap-1">
          <span>Country</span>
          <input name="country" className="p-2 rounded bg-[color:var(--surface)]" />
        </label>
        <label className="grid gap-1">
          <span>How do you want to contribute?</span>
          <textarea name="about" rows={5} className="p-2 rounded bg-[color:var(--surface)]" />
        </label>
        <button disabled={loading} className="px-4 py-2 rounded bg-[color:var(--accent)] text-black w-max">
          {loading ? "Sending..." : "Send"}
        </button>
      </form>
      {ok === true && <p className="mt-4 text-green-400">Thanks. We will get back to you.</p>}
      {ok === false && <p className="mt-4 text-red-400">Something went wrong. Please try again later.</p>}

      <noscript>
        <p className="mt-6 text-sm opacity-80">If JavaScript is disabled, Netlify Forms can be used. Contact us at hello@nuvaar.xyz.</p>
      </noscript>
    </section>
  );
}
