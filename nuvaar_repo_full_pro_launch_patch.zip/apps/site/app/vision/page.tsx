
export default function Vision() {
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Vision</h1>
      <p>We want a world where creative livelihood is possible without giving up dignity. We use small, time-bound groups and transparent governance to make the path practical.</p>
      <h2>Principles</h2>
      <ul>
        <li>Dignity before efficiency</li>
        <li>Small groups with real outcomes</li>
        <li>Technology as service, not master</li>
        <li>Beauty with responsibility</li>
      </ul>
      <h2>Roadmap</h2>
      <ol>
        <li>Pilot 2 Cells and publish results</li>
        <li>Public dashboards and open docs</li>
        <li>Regional ambassadors and cultural exchange</li>
      </ol>
    </article>
  );
}
