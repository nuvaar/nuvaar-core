
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

export const config = { matcher: ["/api/:path*"] };

let fallbackMap: Map<string, { count: number, ts: number }> | null = null;
const WINDOW_MS = 60_000;
const LIMIT = 10;

export async function middleware(req: NextRequest) {
  const ip = req.ip || req.headers.get("x-forwarded-for") || "unknown";
  const url = new URL(req.url);

  if (process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN) {
    // Optional: Upstash implementation (lazy import to keep bundle small)
    const { Ratelimit } = await import("@upstash/ratelimit");
    const { Redis } = await import("@upstash/redis");
    const redis = new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL!,
      token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    });
    const ratelimit = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(LIMIT, "1 m") });
    const { success, limit, reset, remaining } = await ratelimit.limit(`rate:${ip}:${url.pathname}`);
    if (!success) {
      return new NextResponse("Too Many Requests", { status: 429, headers: { "Retry-After": String(Math.ceil((reset - Date.now())/1000)) } });
    }
    return NextResponse.next({
      headers: {
        "X-RateLimit-Limit": String(limit),
        "X-RateLimit-Remaining": String(remaining)
      }
    });
  } else {
    // Safe fallback: in-memory per server instance window
    if (!fallbackMap) fallbackMap = new Map();
    const now = Date.now();
    const key = `${ip}:${url.pathname}`;
    const entry = fallbackMap.get(key);
    if (!entry || now - entry.ts > WINDOW_MS) {
      fallbackMap.set(key, { count: 1, ts: now });
    } else {
      entry.count += 1;
      if (entry.count > LIMIT) {
        return new NextResponse("Too Many Requests", { status: 429 });
      }
    }
    return NextResponse.next();
  }
}
