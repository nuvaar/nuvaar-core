# NUVAAR — Enterprise Hardened

Production ready Next 14 App Router with:
- Public marketing pages (Home, Vision, Minds, FluxSkin, Atlas, DAO, Join)
- Join API with Supabase insert + hCaptcha verification
- Admin panel (token cookie) with Join list + CSV export, KPI (Recharts), R2 uploads
- Security headers (CSP, HSTS, CTO, Frame, Referrer, Permissions)
- Upstash Redis rate limiting middleware
- Sentry client/server init
- SEO, PWA manifest
- SQL migrations (profiles, kpis, join_requests)

## Setup
1. Create Supabase, run SQL in infra/sql/0001_auth_roles_kpis.sql
2. Set envs (.env.example): SUPABASE_*, ADMIN_TOKEN, HCAPTCHA_*, optional R2_*, Snapshot/Safe, Upstash, Sentry
3. Deploy on Vercel (Root Dir: apps/site)

## Admin
Set ADMIN_TOKEN. Go to /admin/login to sign in.
