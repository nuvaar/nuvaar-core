import { createRequire } from "module";
const require = createRequire(import.meta.url);
let withSentry = (c)=>c;
try { withSentry = require("@sentry/nextjs").withSentryConfig; } catch {}
const base = {
  reactStrictMode: true,
  experimental: { optimizePackageImports: ["@supabase/supabase-js"] },
  async headers() {
    const csp = [
      "default-src 'self'",
      "script-src 'self' https://plausible.io https://hcaptcha.com https://*.hcaptcha.com",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob:",
      "font-src 'self' data:",
      "connect-src 'self' https://*.supabase.co https://*.supabase.in https://plausible.io https://hcaptcha.com https://*.hcaptcha.com",
      "frame-src https://hcaptcha.com https://*.hcaptcha.com",
      "object-src 'none'",
      "base-uri 'self'",
      "frame-ancestors 'none'",
      "form-action 'self'"
    ].join("; ");
    return [{
      source: "/(.*)",
      headers: [
        { key: "Content-Security-Policy", value: csp },
        { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
        { key: "X-Content-Type-Options", value: "nosniff" },
        { key: "X-Frame-Options", value: "DENY" },
        { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" }
      ]
    }];
  }
};
export default withSentry(base, { silent: true });
