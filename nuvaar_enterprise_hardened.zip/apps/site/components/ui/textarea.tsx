import React from "react";
export const Textarea = React.forwardRef<HTMLTextAreaElement, React.ComponentProps<'textarea'>>(({ className='', ...props }, ref) => (
  <textarea ref={ref} className={`w-full p-2 rounded bg-surface border border-muted ${className}`} {...props} />
));
Textarea.displayName = "Textarea";
