export function Card({ children, className='' }: any){ return <div className={`rounded-lg border border-muted bg-surface ${className}`}>{children}</div>; }
export function CardHeader({ children, className='' }: any){ return <div className={`p-4 border-b border-muted ${className}`}>{children}</div>; }
export function CardContent({ children, className='' }: any){ return <div className={`p-4 ${className}`}>{children}</div>; }
