export function Label({ children, className='', ...props }: any){ return <label className={`text-sm mb-1 block ${className}`} {...props}>{children}</label>; }
