import React from "react";
export const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<'input'>>(({ className='', ...props }, ref) => (
  <input ref={ref} className={`w-full p-2 rounded bg-surface border border-muted ${className}`} {...props} />
));
Input.displayName = "Input";
