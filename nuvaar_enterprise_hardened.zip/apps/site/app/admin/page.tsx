import Link from "next/link"; 
import { isAdminByCookie } from "@/lib/authrbac";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default async function AdminHome(){
  if(!isAdminByCookie()) return <div className="p-8">Unauthorized</div>;
  return (
    <main className="p-8 grid gap-6">
      <h1 className="text-2xl font-semibold">NUVAAR Admin</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { href: "/admin/join-requests", t: "Join requests", d: "Review and export applicant data" },
          { href: "/admin/kpi", t: "KPI dashboard", d: "Track core impact metrics" },
          { href: "/admin/uploads", t: "Asset uploads", d: "Upload static assets to R2" }
        ].map((x)=> (
          <Card key={x.href}><CardHeader><h2 className="font-semibold">{x.t}</h2></CardHeader><CardContent><p className="text-muted mb-3">{x.d}</p><Link className="underline" href={x.href}>Open</Link></CardContent></Card>
        ))}
      </div>
      <form method="post" action="/admin/logout"><button className="mt-6 border px-3 py-1 rounded">Sign out</button></form>
    </main>
  );
}
