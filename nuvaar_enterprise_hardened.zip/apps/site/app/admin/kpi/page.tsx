import { isAdminByCookie } from "@/lib/authrbac"; import { supabaseAdmin } from "@/lib/supabaseAdmin";
import dynamic from "next/dynamic";
const ResponsiveContainer = dynamic(() => import("recharts").then(m => m.ResponsiveContainer), { ssr: false });
const LineChart = dynamic(() => import("recharts").then(m => m.LineChart), { ssr: false });
const Line = dynamic(() => import("recharts").then(m => m.Line), { ssr: false });
const XAxis = dynamic(() => import("recharts").then(m => m.XAxis), { ssr: false });
const YAxis = dynamic(() => import("recharts").then(m => m.YAxis), { ssr: false });
const Tooltip = dynamic(() => import("recharts").then(m => m.Tooltip), { ssr: false });
const Legend = dynamic(() => import("recharts").then(m => m.Legend), { ssr: false });
export default async function KPI(){
  if(!isAdminByCookie()) return <div className="p-8">Unauthorized</div>;
  const { data } = await supabaseAdmin.from("kpis").select("*").order("created_at",{ascending:true});
  const series=["active_users","active_cells","completed_projects","ecosystem_revenue","return_rate"];
  const ds=Object.fromEntries(series.map(s=>[s,(data||[]).filter(d=>d.metric===s).map(d=>({t:d.created_at,v:d.value}))]));
  return (<main className="p-8 space-y-8"><h1 className="text-2xl font-semibold">KPI Dashboard</h1>
    {series.map(s=>(<div key={s} className="h-64 w-full border rounded p-2"><h2 className="mb-2">{s}</h2><ResponsiveContainer width="100%" height="100%"><LineChart data={ds[s]}><XAxis dataKey="t" tick={{fontSize:12}}/><YAxis/><Tooltip/><Legend/><Line type="monotone" dataKey="v" dot={false}/></LineChart></ResponsiveContainer></div>))}
  </main>);
}
