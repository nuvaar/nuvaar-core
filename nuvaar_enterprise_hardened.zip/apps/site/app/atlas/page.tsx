
export default function Page(){
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Atlas</h1>
      <p>Content draft. Replace with full copy later.</p>
    </article>
  );
}
