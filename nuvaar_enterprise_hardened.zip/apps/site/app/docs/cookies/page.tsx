export default function Page(){
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Cookie Policy</h1>
      <p>We use minimal cookies to operate the service and measure usage (e.g., session or analytics).</p>
    </article>
  );
}
