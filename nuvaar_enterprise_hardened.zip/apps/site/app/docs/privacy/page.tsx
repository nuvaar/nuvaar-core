export default function Page(){
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Privacy Policy</h1>
      <p>We collect the minimum data to operate the service and ensure safety.</p>
      <h2>Data</h2>
      <ul><li>Account email and profile.</li><li>Join form submissions you send.</li><li>Aggregate analytics without personal identifiers.</li></ul>
      <h2>GDPR basis</h2>
      <ul><li>Consent for optional features.</li><li>Contract for core features.</li><li>Legitimate interest for security.</li></ul>
      <h2>Retention</h2><p>We keep data only as long as necessary. You can request deletion.</p>
      <h2>Rights</h2><p>Access, rectification, deletion, portability, objection.</p>
      <h2>Sharing</h2><p>Trusted processors like Vercel and Supabase. No sale of personal data.</p>
      <h2>Security</h2><p>Encryption in transit, role based access, rate limiting, incident response.</p>
      <h2>International transfers</h2><p>Standard contractual clauses where applicable.</p>
      <h2>Contact</h2><p>legal@nuvaar.xyz</p>
    </article>
  );
}
