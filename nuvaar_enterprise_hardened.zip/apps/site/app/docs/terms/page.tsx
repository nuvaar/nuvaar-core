export default function Page(){
  return (
    <article className="prose prose-invert max-w-3xl">
      <h1>Terms of Use</h1>
      <p>These Terms govern access to and use of NUVAAR services and websites. By using the service you agree to these Terms.</p>
      <h2>Accounts</h2><p>You are responsible for your account and security.</p>
      <h2>Acceptable use</h2>
      <ul><li>No harassment or discrimination.</li><li>No abuse or disruption.</li><li>Respect privacy and IP.</li></ul>
      <h2>Content and ownership</h2><p>Creators own their works. Public content is shared under CC BY-NC-SA unless otherwise agreed.</p>
      <h2>Disclaimer and liability</h2><p>Service is provided as is. NUVAAR is not liable for indirect damages.</p>
      <h2>Contact</h2><p>legal@nuvaar.xyz</p>
    </article>
  );
}
