export default function Home(){
  return (
    <section className="grid gap-8">
      <div className="grid gap-4">
        <h1 className="text-4xl font-semibold">Dignity. Small groups. Real outcomes.</h1>
        <p className="text-lg text-muted max-w-2xl">We organize creative work and mutual support in small Cells so people can build livelihood with dignity.</p>
        <div className="flex gap-4">
          <a className="px-4 py-2 rounded bg-accent text-black" href="/join">Join</a>
          <a className="px-4 py-2 rounded border border-muted" href="/vision">Read the vision</a>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { t: "Cell DAO", d: "3 to 12 people, 6 to 12 weeks, clear outcomes and shared care."},
          { t: "Transparency", d: "Snapshot votes and a multi sig treasury you can verify."},
          { t: "Low data", d: "We collect the minimum required. People first, always."}
        ].map((c) => (
          <div key={c.t} className="p-4 rounded bg-surface border border-muted">
            <h3 className="font-semibold mb-1">{c.t}</h3>
            <p className="text-muted">{c.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
