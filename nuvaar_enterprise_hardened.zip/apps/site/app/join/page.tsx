"use client";
import { useEffect, useState } from "react";
import { submitJoin } from "@/lib/joinClient";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export default function JoinPage(){
  const [ok,setOk] = useState<boolean|null>(null);
  const [loading,setLoading] = useState(false);
  const [siteKey, setSiteKey] = useState<string | null>(null);
  useEffect(()=>{ fetch("/api/hc/sitekey").then(r=>r.json()).then(j=>setSiteKey(j.siteKey||null)); },[]);
  useEffect(()=>{ if(!siteKey) return; const s=document.createElement("script"); s.src="https://hcaptcha.com/1/api.js"; s.async=true; document.body.appendChild(s); return ()=>{document.body.removeChild(s)}; },[siteKey]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>){
    e.preventDefault(); setLoading(true);
    const res = await submitJoin(e.currentTarget);
    setLoading(false); setOk(!!res?.ok);
    if(res?.ok) e.currentTarget.reset();
  }
  return (<section className="max-w-2xl">
    <h1 className="text-3xl font-semibold mb-4">Join NUVAAR</h1>
    <form onSubmit={onSubmit} className="grid gap-4">
      <div><Label>Name</Label><Input name="name" required /></div>
      <div><Label>Email</Label><Input type="email" name="email" required /></div>
      <div><Label>Country</Label><Input name="country" /></div>
      <div><Label>How do you want to contribute?</Label><Textarea name="about" rows={5} /></div>
      {siteKey ? <div className="h-captcha" data-sitekey={siteKey}></div> : <p className="text-muted">Loading captcha...</p>}
      <Button disabled={loading} type="submit">{loading ? "Sending..." : "Send"}</Button>
    </form>
    {ok===true && <p className="mt-4 text-green-400">Thanks. We will get back to you.</p>}
    {ok===false && <p className="mt-4 text-red-400">Something went wrong. Please try again later.</p>}
  </section>);
}
