import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
export const runtime = "nodejs";
const Schema = z.object({
  name: z.string().min(1).max(120),
  email: z.string().email(),
  country: z.string().max(80).optional(),
  about: z.string().max(5000).optional(),
  ua: z.string().optional(),
  hcaptcha: z.string().optional()
});
async function checkCaptcha(token?: string){
  const secret = process.env.HCAPTCHA_SECRET_KEY;
  if(!secret) return true;
  if(!token) return false;
  const body = new URLSearchParams({ secret, response: token });
  const res = await fetch("https://hcaptcha.com/siteverify", { method:"POST", headers:{ "content-type":"application/x-www-form-urlencoded" }, body });
  if(!res.ok) return false;
  const data = await res.json();
  return !!data?.success;
}
export async function POST(req: Request){
  try{
    const payload = await req.json();
    payload.hcaptcha = payload["h-captcha-response"] || payload.hcaptcha;
    const parsed = Schema.safeParse(payload);
    if(!parsed.success) return NextResponse.json({ ok:false, error: parsed.error.flatten() }, { status:400 });
    const ok = await checkCaptcha(parsed.data.hcaptcha);
    if(!ok) return NextResponse.json({ ok:false, error:"captcha_failed" }, { status:403 });
    const { name, email, country, about, ua } = parsed.data;
    const { error } = await supabaseAdmin.from("join_requests").insert({ name, email, country, about, ua });
    if(error) return NextResponse.json({ ok:false, error:"db_error" }, { status:500 });
    return NextResponse.json({ ok:true });
  }catch(e){ return NextResponse.json({ ok:false, error:"bad_request" }, { status:400 }); }
}
