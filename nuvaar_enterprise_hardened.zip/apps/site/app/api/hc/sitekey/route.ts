export async function GET(){return new Response(JSON.stringify({ siteKey: process.env.HCAPTCHA_SITE_KEY || null }), { headers:{'content-type':'application/json'} });}
