import "./../styles/globals.css";
export const metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: { default: "NUVAAR", template: "%s • NUVAAR" },
  description: "NUVAAR organizes creative work and mutual support in small Cells so people can build livelihood with dignity.",
  openGraph: { title: "NUVAAR", description: "Small groups. Real outcomes. Dignity first.", images: ["/og.png"] }
};
export default function RootLayout({ children }: { children: React.ReactNode }){
  const domain = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;
  return (
    <html lang="en">
      <body>
        <header className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2">
            <img src="/brand/nuvaar-logo-dark.png" alt="NUVAAR" className="h-8 w-auto" />
          </a>
          <nav className="flex gap-5">
            <a href="/vision">Vision</a>
            <a href="/minds">Minds</a>
            <a href="/fluxskin">FluxSkin</a>
            <a href="/atlas">Atlas</a>
            <a href="/dao">DAO</a>
            <a href="/join" className="px-3 py-1 rounded bg-accent text-black">Join</a>
          </nav>
        </header>
        <main className="max-w-6xl mx-auto px-6 py-10">{children}</main>
        <footer className="max-w-6xl mx-auto px-6 py-10 border-t border-muted text-sm flex flex-wrap gap-4">
          <a href="/docs/terms">Terms</a>
          <a href="/docs/privacy">Privacy</a>
          <a href="/docs/cookies">Cookies</a>
          <span>legal@nuvaar.xyz</span>
        </footer>
        {domain ? (<script defer data-domain={domain} src="https://plausible.io/js/script.js" />) : null}
      </body>
    </html>
  );
}
