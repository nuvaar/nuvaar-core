import { NextRequest, NextResponse } from "next/server";
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
export const config = { matcher: ["/api/:path*"] };
const redis = process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN ? new Redis({ url: process.env.UPSTASH_REDIS_REST_URL, token: process.env.UPSTASH_REDIS_REST_TOKEN }) : null;
const limiter = redis ? new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(20, "1 m") }) : null;
export async function middleware(req: NextRequest) {
  if (!limiter) return NextResponse.next();
  const ip = req.ip || req.headers.get("x-forwarded-for") || "127.0.0.1";
  const key = `${ip}:${new URL(req.url).pathname}`;
  const { success, limit, reset, remaining } = await limiter.limit(key);
  const res = success ? NextResponse.next() : new NextResponse("Too Many Requests", { status: 429 });
  res.headers.set("X-RateLimit-Limit", String(limit));
  res.headers.set("X-RateLimit-Remaining", String(remaining));
  res.headers.set("X-RateLimit-Reset", String(reset));
  return res;
}
